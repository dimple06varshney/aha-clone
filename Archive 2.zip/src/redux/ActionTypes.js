export const ADD_LOGIN = 'ADD_LOGIN'
export const ADD_PAYMENT = 'ADD_PAYMENT'
export const ADD_LANG = 'ADD_LANG'
export const ADD_DATA = 'ADD_DATA'